package libClases;

public class ClienteTarifaPlana extends Cliente { // ClienteTarifaPlana hereda de Cliente.
													// No hace falta implementar interfaces porque estan heredadas.
	private String nacionalidad;
	private float minutosHablados;
	private static final float PRECIOEXCESOMINUTOS = 0.15f;
	private static float precioTarifa = 20f;
	private static float minutos = 300f;

	public ClienteTarifaPlana(String NIF, String nombre, Fecha fechaNacimiento, Fecha fechaAlta,
			float minutosHabladosParametro, String nacionalidadParametro) {
		super(NIF, nombre, fechaNacimiento, fechaAlta);
		nacionalidad = nacionalidadParametro;
		minutosHablados = minutosHabladosParametro;
	}

	public ClienteTarifaPlana(String nif, String nombre, Fecha fechaNacimiento, float minutosHabladosParametro,
			String nacionalidadParametro) {
		super(nif, nombre, fechaNacimiento);
		nacionalidad = nacionalidadParametro;
		minutosHablados = minutosHabladosParametro;
	}

	public ClienteTarifaPlana(ClienteTarifaPlana c) {
		super(c.getNif(), c.getNombre(), c.getFechaNac(), c.getFechaAlta());
		nacionalidad = c.nacionalidad;
		minutosHablados = c.minutosHablados;
	}

	public float factura() {
		float factura;
		if (minutosHablados <= minutos)
			factura = precioTarifa;
		else {
			float min;
			min = minutosHablados - minutos;
			factura = precioTarifa + (min * PRECIOEXCESOMINUTOS);
		}
		return factura;
	}

	public void setNacionalidad(String nacionalidadParametro) {
		nacionalidad = nacionalidadParametro;
	}

	public String getNacionalidad() {
		return nacionalidad;
	}

	public float getMinutos() {
		return minutosHablados;
	}

	public void setMinutos(float min) {
		minutosHablados = min;
	}

	public static void setTarifa(float min, float prec) {
		minutos = min;
		precioTarifa = prec;
	}

	public static float getLimite() {
		return minutos;
	}

	public static float getTarifa() {
		return precioTarifa;
	}

	public boolean equals(Object obj) {
		boolean resultado = false;
		if (super.equals(obj) && obj.getClass() == this.getClass())
			resultado = true;
		return resultado;
	}

	public String toString() {
		String cad = super.toString() + " " + nacionalidad + " [" + minutos + " por " + precioTarifa + "] "
				+ minutosHablados + " --> " + factura();
		return cad;
	}

	public Object clone() {
		ClienteTarifaPlana c = new ClienteTarifaPlana(this);
		return c;
	}

}