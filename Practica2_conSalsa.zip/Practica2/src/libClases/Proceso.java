package libClases;

public interface Proceso {
	public abstract boolean equals(Object obj); // true sin son iguales
	void ver();									// muestra en pantalla el objeto
}