package libClases;

public interface Facturable { /**/ /* 1.c) */
    void mostrarFacturaMedia();
}