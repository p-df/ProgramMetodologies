#ifndef CONTRATOESPECIAL_H
#define CONTRATOESPECIAL_H

#include "Contrato.h"
#include "Cliente.h"

class ContratoEspecial : public Contrato {
public:
    ContratoEspecial(long int dni, Fecha f);
    float calcularFactura() const;
    virtual ~ContratoEspecial() {}

};

#endif // CONTRATOESPECIAL_H
