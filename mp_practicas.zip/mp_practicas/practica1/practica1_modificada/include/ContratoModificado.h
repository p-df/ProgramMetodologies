#ifndef CONTRATOMODIFICADO_H
#define CONTRATOMODIFICADO_H


class ContratoModificado
{
    public:
        ContratoModificado();
        virtual ~ContratoModificado();

    protected:

    private:
};

#endif // CONTRATOMODIFICADO_H
