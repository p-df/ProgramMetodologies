#include "ContratoEspecial.h"
#include "Cliente.h"
#include <iostream>

ContratoEspecial::ContratoEspecial(long int dni, Fecha f) : Contrato(dni, f) {}

float ContratoEspecial::calcularFactura() const {

    int facturaModificada;
    return facturaModificada;
}
