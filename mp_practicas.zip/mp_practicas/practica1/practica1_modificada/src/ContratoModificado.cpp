#include "ContratoModificado.h"

ContratoModificado::ContratoModificado()
{
    //ctor
}

ContratoModificado::~ContratoModificado()
{
    //dtor
}
