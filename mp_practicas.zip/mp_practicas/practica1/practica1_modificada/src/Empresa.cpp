#include "Empresa.h"
#include "Contrato.h"
#include "Fecha.h"
#include "Cliente.h"
#include <cstring>
#include <iostream>
#include <typeinfo>

//el constructor de la clase empresa debe crear un array din�mico de tama�o inicial 10
//debe inicializar a 0 los contadores de clientes (ncli) y contratos (ncon)
//y debe inicializar la constante nmaxcli a 100 y la variable nmaxcon a 10
Empresa::Empresa():nmaxcli(100) {
    this->ncli=0;
    this->ncon=0;
    this->contratos=new Contrato *[10]; //inicialmente capacidad para 10 Contratos
    this->nmaxcon=10;
}

//el destructor debe, adem�s de eliminar el array din�mico creado en el constructor,
//eliminar los objetos clientes y contratos apuntados por ambos arrays
Empresa::~Empresa() {
    for(int i=0; i<this->ncon; i++) { //primero elimino los objetos contratos
        delete this->contratos[i];
    }
    delete [] this->contratos; //luego elimino el array de punteros
    for(int i=0; i<this->ncli; i++) { //primero elimino los objetos contratos
        delete this->clientes[i];
    }
    //delete [] this->clientes; //ERROR el array clientes no es din�mico
}

//m�todo auxiliar usado por el m�todo crearContrato
int Empresa::altaCliente(Cliente *c) { //a�ade cliente apuntado por c al array clientes
    int pos=-1;                         //devuelve -1 si no cabe y la posici�n donde
    if (this->ncli<nmaxcli) {           //donde lo he metido si cabe
        this->clientes[this->ncli]=c;
        pos=this->ncli;
        this->ncli++;
    }
    else {
        cout << "Lo siento, el cupo de clientes esta lleno";
        pos=-1;
    }
    return pos;
}

//m�todo auxiliar usado por el m�todo crearContrato
int Empresa::buscarCliente(long int dni) const { //si no existe devuelve -1 y si existe
    //devuelve la posici�n del cliente
    //A IMPLEMENTAR POR EL ALUMNO... //con ese dni en el array clientes
    bool esta = false;
    int i;

    for(i=0; i<ncli && esta==false; i++)
        if(dni==this->clientes[i]->getDni())
            esta = true;

    if(esta==true)
        return i-1;
    else
        return -1;
}

void Empresa::crearContrato() { //EL ALUMNO DEBE TERMINAR DE IMPLEMENTAR ESTE METODO
    long int dni;
    int pos;
    cout << endl << "Introduzca dni: ";
    cin >> dni;
    //supongo que hay un metodo buscarCliente(dni) que devuelve -1 si no existe y si
    //existe devuelve la posicion del cliente en el array this->cli
    pos=this->buscarCliente(dni); //OJO ESTE METODO HAY QUE IMPLEMENTARLO
    if (pos==-1) { //el cliente no existe y hay que darlo de alta
        int dia, mes, anio;
        char nombre[100];
        Cliente *c; //NO CREO NINGUN CLIENTE SINO SOLO UN PUNTERO A CLIENTE

        cin.ignore();
        cout << "Nombre del cliente: ";
        cin.getline(nombre,100);
        cout << "dia: ";
        cin >> dia;
        cout << "mes: ";
        cin >> mes;
        cout << "anio: ";
        cin >> anio;
        c=new Cliente(dni, nombre, Fecha(dia, mes, anio));
        pos=this->altaCliente(c); //OJO HAY QUE IMPLEMENTARLO
    }
    //viendo cuanto vale la variable pos s� si el cliente se ha dado de alta o no
    if (pos!=-1) { //el cliente existe o se ha dado de alta
    //PREGUNTAR QUE TIPO DE CONTRATO QUIERE Y LOS DATOS NECESARIOS
    //CREAR EL OBJETO CONTRATO CORRESPONDIENTE Y A�ADIR AL ARRAY
    //contratos UN PUNTERO A DICHO OBJETO
        int tipo;

        this->ncon++;

        do {
            cout << "Tipo de Contrato a abrir (1-Tarifa Plana, 2-Movil): ";
            cin >> tipo;
        } while(tipo!=1 && tipo!=2);

        if(tipo==1) {
            int m, d, mes, a;

            cout << "Fecha del contrato" << endl
                 << "dia: ";
            cin >> d;
            cout << "mes: ";
            cin >> mes;
            cout << "anio: ";
            cin >> a;
            cout << "minutos hablados: ";
            cin >> m;

            this->contratos[ncon-1] = new ContratoTP(dni, Fecha(d, mes, a), m);
        }
        else if(tipo==2) {
            int m, d, mes, a;
            float p_m;
            char nac[100];

            cout << "Fecha del contrato" << endl
                 << "dia: ";
            cin >> d;
            cout << "mes: ";
            cin >> mes;
            cout << "anio: ";
            cin >> a;
            cout << "minutos hablados: ";
            cin >> m;
            cout << "Precio minuto: ";
            cin >> p_m;
            cout << "Nacionalidad: ";
            cin >> nac;

            this->contratos[ncon-1] = new ContratoMovil(dni, Fecha(d, mes, a), p_m, m, nac);
        }
    }
}

bool Empresa::cancelarContrato(int idContrato) {
    bool esta = false;
    int i;

    for(i=0; i<ncon && esta==false; i++)
        if(idContrato==this->contratos[i]->getIdContrato())
            esta = true;

    if(esta==false)
        cout << "El contrato no existe" << endl;
    else {
        delete this->contratos[i-1];
        for(int j=i; j<ncon; j++)
            this->contratos[j-1] = this->contratos[j];
        this->ncon--;
    }

    return esta;
}

bool Empresa::bajaCliente(long int dni) {
    int pos = this->buscarCliente(dni);

    if(pos==-1)
        return false;
    else {
        delete this->clientes[pos];
        for(int i=pos+1; i<this->ncli; i++)
            this->clientes[i-1] = this->clientes[i];
        this->ncli--;

        for(int j=this->ncon-1; j>=0; j--)
            if(dni==this->contratos[j]->getDniContrato())
                cancelarContrato(this->contratos[j]->getIdContrato());

        return true;
    }
}

int Empresa::descuento (float porcentaje) const {
    int n = 0;

    for(int i=0; i<this->ncon; i++)
        if(dynamic_cast<ContratoMovil*>(contratos[i])!=0) {
            float nuevoPrecio;

            n++;
            ContratoMovil *cm = dynamic_cast<ContratoMovil*>(contratos[i]);
            nuevoPrecio = cm->getPrecioMinuto()*(1.00-porcentaje/100);
            cm->setPrecioMinuto(nuevoPrecio);
            contratos[i] = dynamic_cast<Contrato*>(cm);
        }

    return n;
}

int Empresa::nContratosTP() const {
    int n = 0;

    for(int i=0; i<ncon; i++)
        if(typeid(*this->contratos[i])==typeid(ContratoTP))
            n++;

    return n;
}

void Empresa::cargarDatos() {
    Fecha f1(29,2,2001), f2(31,1,2002), f3(1,2,2002);
    this->clientes[0] = new Cliente(75547001, "Peter Lee", f1);
    this->clientes[1] = new Cliente(45999000, "Juan Perez", Fecha(29,2,2000));
    this->clientes[2] = new Cliente(37000017, "Luis Bono", f2);
    this->ncli=3;

    this->contratos[0] = new ContratoMovil(75547001, f1, 0.12, 110, "DANES"); //habla 110m a 0.12�/m
    this->contratos[1] = new ContratoMovil(75547001, f2, 0.09, 170, "DANES"); //habla 170m a 0.09�/m
    this->contratos[2] = new ContratoTP(37000017, f3, 250); //habla 250m (300m a 10�, exceso 0.15�/m)
    this->contratos[3] = new ContratoTP(75547001, f1, 312); //habla 312m (300m a 10�, exceso 0.15�/m)
    this->contratos[4] = new ContratoMovil(45999000, f2, 0.10, 202, "ESPANYOL"); //habla 202m a 0.10/m
    this->contratos[5] = new ContratoMovil(75547001, f2, 0.15, 80, "DANES"); //habla 80m a 0.15�/m
    this->contratos[6] = new ContratoTP(45999000, f3, 400); //habla 400m (300m a 10�, exceso 0.15�/m)
    this->ncon=7;
}

void Empresa::ver() const {
    cout << endl << "La Empresa tiene " << ncli << " clientes y " << ncon << " contratos" << endl
         << "Clientes:" << endl;
    for(int i=0; i<ncli; i++)
        cout << *this->clientes[i] << endl;

    cout << endl << "Contratos:" << endl;
    for(int j=0; j<ncon; j++)
        if(typeid(*contratos[j])==typeid(ContratoTP)) {
            ContratoTP *cTP = dynamic_cast<ContratoTP*>(contratos[j]);
            cTP->ver();
            cout << " - " << cTP->factura() << "eur" << endl;
        }
        else {
            ContratoMovil *cm = dynamic_cast<ContratoMovil*>(contratos[j]);
            cm->ver();
            cout << " - " << cm->factura() << "eur" << endl;
        }
}

int Empresa::nContratosMovil() const {
    int n = 0;

    for(int i=0; i<ncon; i++)
        if(typeid(*this->contratos[i])==typeid(ContratoTP))
            n++;

    return n;
}

int Empresa::nContratosMconFacturaSobreLaMedia() const {

    int sumaTotalFacturasContratosMovil;
    int nContratosMfacturasSobreLaMedia;

    int i;
    for(i=0; i<ncon; i++)
        if(typeid(*this->contratos[i])==typeid(ContratoMovil)){
            ContratoMovil *cm = dynamic_cast<ContratoMovil*>(contratos[i]);
            sumaTotalFacturasContratosMovil+=cm->factura();
        }
    for(i=0; i<ncon; i++)
        if(typeid(*this->contratos[i])==typeid(ContratoMovil)){
            ContratoMovil *cm = dynamic_cast<ContratoMovil*>(contratos[i]);
            if (cm->factura() > (sumaTotalFacturasContratosMovil/this->nContratosMovil())) {
                nContratosMfacturasSobreLaMedia++;
            }
        }
    return nContratosMfacturasSobreLaMedia;
}

int Empresa::sumaFacturasTP() const {
    int suma = 0;
    for(int i=0; i<ncon; i++)
        if(typeid(*this->contratos[i])==typeid(ContratoTP)){
            ContratoTP *ct = dynamic_cast<ContratoTP*>(contratos[i]);
            suma+=ct->factura();
        }
    return suma;
}
