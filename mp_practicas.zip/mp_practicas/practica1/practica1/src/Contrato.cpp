#include "Contrato.h"

int Contrato::contador=1;

Contrato::Contrato(long int dni, Fecha f): idContrato(contador), fechaContrato(f) {
  //idContrato=contador; //ERROR es constante y debe ir en zona inicializadores
  Contrato::contador++;
  this->dniContrato=dni;
  //this->fechaContrato=f; //ERROR es tipo no primitivo y debe ir en zona inicializadores
}

Contrato::~Contrato() {
    //dtor
}


void Contrato::ver() const {
  cout << this->dniContrato << " (" << this->idContrato << " - ";
  const char *meses[] = {"", "ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"};
  if (this->fechaContrato.getDia() < 10)
    cout << "0";
  cout << this->fechaContrato.getDia() << " " << meses[this->fechaContrato.getMes()] << " " << this->fechaContrato.getAnio() << ")"; //llamo al ver del objeto fecha
}

ostream& operator<<(ostream &s, const Contrato &c) {
  s << c.getDniContrato() << " (" << c.getIdContrato() << " - " << c.getFechaContrato() << ")";
  return s;
}

//RESTO DE METODOS Y FUNCIONES A RELLENAR POR EL ALUMNO...

Contrato::Contrato(const Contrato& c): idContrato(c.contador), fechaContrato(c.fechaContrato) {
    Contrato::contador++;
    this->dniContrato=c.dniContrato;
}
