#include "ContratoTP.h"
#include "Contrato.h"

int ContratoTP::minutosTP=300;
float ContratoTP::precioTP=10;
const float ContratoTP::precioExcesoMinutos=0.15;


//static se pone en el .h (no se pone en el .cpp)
void ContratoTP::setTarifaPlana(int m, float p) {
  ContratoTP::minutosTP=m; //puedo poner minutosTP=m ...pongo ContratoTP::minutosTP para recordar que es estatico
  ContratoTP::precioTP=p;  //puedo poner precioTP=p  ...pongo ContratoTP::precioTP para recordar que es estatico
}

//RESTO DE METODOS Y FUNCIONES A RELLENAR POR EL ALUMNO...

ContratoTP::ContratoTP(long int dni, Fecha f, int m): Contrato(dni, f) {
    this->minutosHablados=m;
}

float ContratoTP::factura() const {
    int excesoLimMin = 0;

    if(minutosHablados>minutosTP)
        excesoLimMin = minutosHablados-minutosTP;

    return (precioTP + excesoLimMin*precioExcesoMinutos);
}

void ContratoTP::ver() const {
    Contrato::ver();
    cout << " " << this->minutosHablados << "m, " << this->minutosTP << "(" << this->precioTP << ")";
}

ostream& operator<<(ostream &s, const ContratoTP &c) {
    s << (Contrato &)c;
    s << " " << c.getMinutosHablados() << "m, " << c.getLimiteMinutos() << "(" << c.getPrecio() << ") - " << c.factura() << "�";

    return s;
}
