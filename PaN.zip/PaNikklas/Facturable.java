package libClases;

public interface Facturable {
    void mostrarFacturaMedia();
}