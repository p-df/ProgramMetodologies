package libClases;

import java.util.Scanner;

public final class Fecha implements Cloneable, Proceso {

	private int dia, mes, anio;

	public void setFecha(int d, int m, int a) {
		int dmax, diaMes[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		anio = a; // VIP debo asignar año para al llamar a bisiesto() tengo el año bien
		if (m < 1) // si el mes es incorrecto
			m = 1;
		else if (m > 12) // si el mes es incorrecto
			m = 12;
		dmax = diaMes[m - 1];
		if (m == 2 && bisiesto())
			dmax++;
		if (d > dmax)
			d = dmax;
		else if (d < 1)
			d = 1;
		dia = d;
		mes = m;
	}

	public Fecha(int dia, int mes, int anio) {
		setFecha(dia, mes, anio);
	}

	public Fecha(Fecha f) {
		this(f.dia, f.mes, f.anio);
	}

	@Override
	public String toString() {
		return String.format("%02d/%02d/%02d", dia, mes, anio);
	}

	public boolean bisiesto() {
		return anio % 400 == 0 || (anio % 4 == 0 && anio % 100 != 0);
	}
	
	@Override
	public void ver() {
		System.out.println(this);
	}
	
	public static Fecha pedirFecha() {
		Fecha fecha = null;
		boolean valida = false;
		Scanner sc = new Scanner(System.in);
		int dia, mes, anio;

		do {
			System.out.print("Introduce la Fecha (dd/mm/aaaa): ");
			String cadena = sc.next();
			String[] tokens = cadena.split("/");
			try {
				if (tokens.length != 3)
					throw new NumberFormatException();

				dia = Integer.parseInt(tokens[0]); // parseInt lanza la excepcion
				mes = Integer.parseInt(tokens[1]); // NumberFormatException si no
				anio = Integer.parseInt(tokens[2]);// puede convertir el String a int

				fecha = new Fecha(dia, mes, anio);

				if (fecha.getDia() != dia || fecha.getMes() != mes)
					throw new NumberFormatException();

				valida = true;

			} catch (NumberFormatException e) {
				System.out.println("Fecha no valida");
			}

		} while (!valida);

		// sc.close(); // el codigo da error si cierro el Scanner aqui
		return fecha;
	}
	
	public static boolean mayor(Fecha f1, Fecha f2) {
		return f1.anio > f2.anio || (f1.anio == f2.anio && f1.mes > f2.mes)
				|| (f1.anio == f2.anio && f1.mes == f2.mes && f1.dia > f2.dia);
	}
	
	@Override
	public Object clone() {
		Object obj = null;
		try {
			obj = super.clone();
		} catch (CloneNotSupportedException ex) {

		}
		return obj;
	}
	
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Fecha))
			return false;
		Fecha f = (Fecha) o;
		return (dia == f.dia && mes == f.mes && anio == f.anio);
	}
	
	public Fecha diaSig() {
		Fecha f = (Fecha) clone();

		f.dia++;

		int maxDias[] = { 0, 31, bisiesto() ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

		if (f.dia > maxDias[f.mes]) {
			f.dia -= maxDias[f.mes];
			f.mes++;
			if (f.mes > 12) {
				f.mes = 1;
				f.anio++;
			}
		}

		return f;
	}
	
	public int getDia() {
		return dia;
	}

	public int getMes() {
		return mes;
	}

	public int getAnio() {
		return anio;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	public static void main(String[] args) {

		Fecha f1 = new Fecha(29, 2, 2001), f2 = new Fecha(f1), f3 = new Fecha(29, 2, 2004);
		final Fecha f4 = new Fecha(05, 12, 2023); // es constante la referencia f4

		System.out.println("Fechas: " + f1.toString() + ", " + f2 + ", " + f3 + ", " + f4 + "\n");

		f1 = new Fecha(31, 12, 2016); // 31/12/2016
		f4.setFecha(28, 2, 2008); // pero no es constante el objeto al que apunta

		System.out.println(f1 + " " + f2.toString() + " " + f3 + " " + f4 + " " + f1);

		f1 = new Fecha(f4.getDia() - 10, f4.getMes(), f4.getAnio() - 7); // f1=18/02/2001
		f3 = Fecha.pedirFecha(); // pide una fecha por teclado

		if (f3.bisiesto() && Fecha.mayor(f2, f1))
			System.out.print("El " + f3.getAnio() + " fue bisiesto, " + f1 + ", " + f3);

	}
}