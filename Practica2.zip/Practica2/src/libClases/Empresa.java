package libClases;

import java.util.Scanner;

public class Empresa implements Cloneable {
	private Cliente clientes[];
	private int nCli;
	private static int nMaxCli = 10;

	public Empresa() { // Ctror por defecto.
		nCli = 0;
		clientes = new Cliente[nMaxCli]; // Le reservamos memoria a clientes. 'clientes' es un puntero a un arreglo de
											// tipo clientes con nMaxCli elementos.
	}

	public Empresa(Empresa e) { // Ctror de copia.
		nCli = e.nCli;
		clientes = new Cliente[e.nMaxCli];
	}

	public float factura() {
		float f = 0;
		for (int i = 0; i < nCli; i++) {
			if (clientes[i] instanceof ClienteMovil) // Si el cliente[i] es de la clase ClienteMovil.
				f += ((ClienteMovil) clientes[i]).factura(); // Hacemos casting, incluso si queremos ejecutar metodos.
			else if (clientes[i] instanceof ClienteTarifaPlana)
				f += ((ClienteTarifaPlana) clientes[i]).factura();
		}
		return f;
	}

	public void alta() { // Metodo para el alta de un cliente sin parametros.
		Cliente c = null;
		String dni, nombre, nac;
		Fecha fNac, fAlta, fPer;
		int tipo;
		float min, prec;
		Scanner sc = new Scanner(System.in);
		sc.useDelimiter("\n");
		System.out.print("Dni: ");
		dni = sc.nextLine();
		int pos = existe(dni);

		if (pos == -1) {
			System.out.print("Nombre: ");
			nombre = sc.nextLine();

			System.out.print("Fecha de nacimiento: \n");
			fNac = Fecha.pedirFecha();

			System.out.print("Fecha de alta: \n");
			fAlta = Fecha.pedirFecha();

			System.out.print("Minutos que habla al mes: ");
			min = Float.parseFloat(sc.nextLine());

			do {
				System.out.print("Indique tipo de cliente (1-Movil, 2-Tarifa Plana): ");
				tipo = Integer.parseInt(sc.nextLine());
				if (tipo != 2 && tipo != 1)
					System.out.print("\nERROR al introducir el digito");
			} while (tipo != 2 && tipo != 1);

			if (tipo == 1) {
				System.out.print("Precio por minuto: ");
				prec = Float.parseFloat(sc.nextLine());
				System.out.print("Fecha fin permanencia: \n");
				fPer = Fecha.pedirFecha();
				c = new ClienteMovil(dni, nombre, fNac, fAlta, fPer, min, prec);
				if (nCli == nMaxCli)
					listaLlena();
				clientes[nCli] = c;
				nCli++;
			}

			if (tipo == 2) {
				System.out.print("Nacionalidad: ");
				nac = sc.nextLine();
				c = new ClienteTarifaPlana(dni, nombre, fNac, fAlta, min, nac);
				if (nCli == nMaxCli)
					listaLlena();
				clientes[nCli] = c;
				nCli++;
			}

		} else {
			System.out.print("Ya existe un Cliente con ese dni: \n");
			clientes[pos].ver();
			System.out.print("\n");
		}
		// sc.close(); // el codigo da error si cierro el Scanner aqui
	}

	public void alta(Cliente c) { // Metodo para el alta de un cliente con par�metros.
		if (existe(c.getNif()) == -1) {
			if (nCli == nMaxCli)
				listaLlena();
			clientes[nCli] = c;
			nCli++;
		}
	}

	public int existe(String dni) { // Para comprobar si existe un cliente con el dni pasado por par�metro.
		boolean existe = false;
		int pos = -1;
		int i = 0;
		while (i < nCli && !existe) {
			if (clientes[i].getNif().equals(dni))
				existe = true;
			else
				i++;
		}
		if (existe)
			pos = i;
		return pos;
	}

	public void listaLlena() { // Se ejecuta cuando necesitemos m�s clientes que los disponibles por el array.
		Cliente aux[] = clientes; // Array auxiliar para copiar el arreglo clientes.
		nMaxCli = nMaxCli * 2;
		// Duplicamos el nMax de clientes y al arreglo clientes le asignamos mas memoria
		// asi.
		clientes = new Cliente[nMaxCli];
		for (int i = 0; i < nCli; i++) {
			clientes[i] = aux[i]; // Copio cada valor del arreglo anterior.
		}
	}

	public void baja(String dni) { // Dar de baja un cliente con determinado dni pasado por parametro.
		int pos = existe(dni);
		if (pos != -1) {
			for (int i = pos; i < nCli - 1; i++) {
				clientes[i] = clientes[i + 1];
			}
			nCli--; // Disminuyo el numero de clientes.
		}
	}

	public void baja() { // Dar de baja un cliente con determinado dni pasado por consola.
		Scanner cin = new Scanner(System.in);
		String dni, opc;
		System.out.print("\nIntroduzca nif cliente a dar de baja: ");
		dni = cin.nextLine();
		int pos = existe(dni);
		if (pos == -1)
			System.out.print("\nEl cliente no existe");
		else {
			System.out.print(clientes[pos].toString());
			do {
				System.out.print("\n¿Seguro que desea eliminarlo? (s/n): ");
				opc = cin.nextLine();
				if (!opc.equals("s") && !opc.equals("n"))
					System.out.print("\nERROR al introducir la opcion");
			} while (!opc.equals("s") && !opc.equals("n"));
			if (opc.equals("s")) {
				System.out.print(
						"El cliente " + clientes[pos].getNombre() + " con nif " + dni + " ha sido eliminado\n\n");
				baja(dni);
			} else
				System.out.print("El cliente con nif " + dni + " no se elimina\n");
		}
	}

	public String toString() {
		String cad = clientes[0].toString();
		for (int i = 1; i < nCli; i++) {
			cad += "\n" + clientes[i].toString();
		}
		cad += "\n";
		return cad;
	}

	public int nClienteMovil() { // Funcion que cuenta el numero de clientes moviles en nuestro arreglo clientes.
		int contador = 0;
		for (int i = 0; i < nCli; i++) {
			if (clientes[i] instanceof ClienteMovil)
				contador++; // Si es de la clase ClienteMovil incrementamos.
		}
		return contador;
	}

	public void descuento(int dto) { // Aplicar un descuento (descuento es un entero de 0 a 100).
		for (int i = 0; i < nCli; i++) {
			if (clientes[i] instanceof ClienteMovil)
				((ClienteMovil) clientes[i])
						.setPrecioMinuto(((ClienteMovil) clientes[i]).getPrecioMinuto() * dto / 100);
		}

	}

	public Empresa clone() {
		Empresa e = new Empresa(this);
		for (int i = 0; i < nCli; i++) {
			if (clientes[i] instanceof ClienteMovil)
				e.clientes[i] = new ClienteMovil((ClienteMovil) clientes[i]);
			if (clientes[i] instanceof ClienteTarifaPlana)
				e.clientes[i] = new ClienteTarifaPlana((ClienteTarifaPlana) clientes[i]);
		}
		return e;
	}

	public int getN() {
		return nCli;
	}

	public int mostrarMejorClientes() {
		int nm = 0;
		float fm = 0, ftp = 0;
		ClienteMovil auxM;
		ClienteTarifaPlana auxTP;
		System.out.println("Mejores clientes: \n");
		for (int i = 0; i < nCli; i++) {
			if (clientes[i] instanceof ClienteMovil) {
				auxM = new ClienteMovil((ClienteMovil) clientes[i]);
				if (auxM.factura() > fm) {
					fm = auxM.factura();
				}
			}
			if (clientes[i] instanceof ClienteTarifaPlana) {
				auxTP = new ClienteTarifaPlana((ClienteTarifaPlana) clientes[i]);
				if (auxTP.factura() > ftp) {
					ftp = auxTP.factura();
				}
			}
		}

		for (int i = 0; i < nCli; i++) {
			if (clientes[i] instanceof ClienteMovil) {
				auxM = new ClienteMovil((ClienteMovil) clientes[i]);
				if (auxM.factura() == fm) {
					System.out.println("Movil: " + auxM.getNombre() + " " + auxM.getNif() + ".\n");
					nm++;
				}
			}
			if (clientes[i] instanceof ClienteTarifaPlana) {
				auxTP = new ClienteTarifaPlana((ClienteTarifaPlana) clientes[i]);
				if (auxTP.factura() == ftp) {
					System.out.println("Tarifa Plana: " + auxTP.getNombre() + " " + auxTP.getNif() + ".\n");
					nm++;
				}
			}
		}
		return nm;
	}

	public static void robarMejoresClientesTP(Empresa e1, Empresa e2) {
		ClienteTarifaPlana auxTP;
		for (int i = 0; i < e2.nCli; i++) {
			if (e2.clientes[i] instanceof ClienteTarifaPlana) {
				auxTP = new ClienteTarifaPlana((ClienteTarifaPlana) e2.clientes[i]);
				if (auxTP.getMinutos() > auxTP.getLimite()) {
					e1.alta(auxTP);
					e2.baja(auxTP.getNif());
				}
			}
		}
	}

	public static int descontar(Empresa e, float descuento, int anio) {
		int Si = 0;
		ClienteMovil aux;
		for (int i = 0; i < e.nCli; i++) {
			if (e.clientes[i] instanceof ClienteMovil) {
				aux = new ClienteMovil((ClienteMovil) e.clientes[i]);
				if (aux.getFechaAlta().getAnio() == anio) {
					aux.setPrecioMinuto(aux.getPrecioMinuto() - descuento);
					e.clientes[i].equals(aux);
					Si++;
				}
			}
		}
		return Si;
	}

}
