package libClases;

public class Cliente implements Cloneable, Proceso {
	private final String nif; // dni del cliente (letra incluida) (NO puede cambiar)(inmutable)
	private final int codCliente; // codigo fijo y unico generado por la aplicacion
	private static int contador = 1; // Atributo static que aumentaremos en el contador.
	private String nombre; // nombre completo del cliente (SI se puede modificar)(mutable pero los strings no hay que clonarnos, se asignan punteros nuevos, no se cambia el valor de lo q ya tiene)
	private final Fecha fechaNac; // fecha nacimiento del cliente (NO se puede cambiar)(inmutable no hay metodos para modificarlo)
	private final Fecha fechaAlta; // fecha de alta del cliente (SI se puede modificar)(mutable con metodos)
	static private final Fecha fechaDefault = new Fecha(1, 1, 2018);

	public Cliente(Cliente cliente) {
		this.codCliente = contador;
		contador++;
		this.nif = cliente.nif;
		this.nombre = cliente.nombre;
		this.fechaNac = cliente.fechaNac;
		this.fechaAlta = new Fecha((Fecha) cliente.fechaAlta.clone());
	}

	public Cliente(String NIF, String nom, Fecha fNac) {
		this.codCliente = contador;
		contador++;
		this.nif = NIF;
		this.nombre = nom;
		this.fechaNac = new Fecha(fNac);
		this.fechaAlta = new Fecha(fechaDefault);
	}

	public Cliente(String NIF, String nom, Fecha fNac, Fecha fAlta) {
		codCliente = contador;
		contador++;
		nif = NIF;
		nombre = nom;
		fechaNac = fNac; // no es necesario usar constructor de copia pq es un atributo inmutable ya q no tenemos metodos para modificarlo
		fechaAlta = new Fecha(fAlta);
	}

	public Object clone() {
		Cliente c = new Cliente(this); // Cliente es una clase mutable
		return c;
	}

	public String toString() {
		return nif + " " + fechaNac + ": " + nombre + " (" + codCliente + " - " + fechaAlta + ")";
	}

	public boolean equals(Object obj) {
		boolean resultado = false;
		if (obj.getClass() == this.getClass()) {
			if (((Cliente) obj).nif.equals(this.nif)) {
				resultado = true;
			}
		}
		return resultado;
	}

	public void ver() {
		System.out.println(this);
	}

	public static Fecha getFechaPorDefecto() {
		Fecha f = new Fecha(fechaDefault);
		return f;
	}

	public static void setFechaPorDefecto(Fecha f) {
		fechaDefault.setFecha(f.getDia(), f.getMes(), f.getAnio());
	}

	public void setFechaAlta(Fecha _fechaAlta) {
		this.fechaAlta.setFecha(_fechaAlta.getDia(), _fechaAlta.getMes(), _fechaAlta.getAnio());
	}

	public void setNombre(String _nombre) {
		this.nombre = _nombre;
	}

	public Fecha getFechaNac() {
		return (Fecha) this.fechaNac.clone();
	}

	public Fecha getFechaAlta() {
		return (Fecha) this.fechaAlta.clone();
	}

	public String getNif() {
		return this.nif; // No hay que hacer .clone() de los tipos de datos primitivos y de String
	}

	public String getNombre() {
		return this.nombre;
	}

	public int getCodCliente() {
		return this.codCliente;
	}
}
